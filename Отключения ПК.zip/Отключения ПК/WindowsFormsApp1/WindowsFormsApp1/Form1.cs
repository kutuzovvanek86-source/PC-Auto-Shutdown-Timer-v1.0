﻿using System;
using System.Diagnostics;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        // Оставшееся время до выключения компьютера
        private TimeSpan remainingTime;

        // Показывает, запущен ли таймер
        private bool timerIsRunning = false;

        public Form1()
        {
            InitializeComponent();

            // Окно будет поверх других окон при запуске программы
            this.TopMost = true;

            // Устанавливаем начальное состояние интерфейса
            labelTime.Text = "00:00:00";
            buttonCancel.Enabled = false;

            // Интервал таймера — одна секунда
            timer1.Interval = 1000;
        }

        /// <summary>
        /// Обработчик кнопки «Запустить»
        /// </summary>
        private void buttonStart_Click(object sender, EventArgs e)
        {
            // Получаем часы, минуты и секунды из полей формы
            int hours = (int)numericHours.Value;
            int minutes = (int)numericMinutes.Value;
            int seconds = (int)numericSeconds.Value;

            // Создаём объект времени
            remainingTime = new TimeSpan(hours, minutes, seconds);

            // Нельзя запускать таймер с нулевым временем
            if (remainingTime.TotalSeconds <= 0)
            {
                MessageBox.Show(
                    "Укажите время больше нуля.",
                    "Ошибка",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);

                return;
            }

            // Запоминаем, что таймер запущен
            timerIsRunning = true;

            // Блокируем поля времени во время отсчёта
            numericHours.Enabled = false;
            numericMinutes.Enabled = false;
            numericSeconds.Enabled = false;

            // Кнопка запуска больше не нужна во время отсчёта
            buttonStart.Enabled = false;

            // Включаем кнопку отмены
            buttonCancel.Enabled = true;

            // Показываем время на экране
            UpdateTimeLabel();

            // Запускаем таймер
            timer1.Start();
        }

        /// <summary>
        /// Обработчик кнопки «Отменить»
        /// </summary>
        private void buttonCancel_Click(object sender, EventArgs e)
        {
            // Останавливаем таймер программы
            timer1.Stop();

            // Отменяем запланированное выключение Windows,
            // если оно было запущено ранее
            CancelWindowsShutdown();

            // Сбрасываем состояние программы
            timerIsRunning = false;
            remainingTime = TimeSpan.Zero;

            // Обновляем надпись
            labelTime.Text = "00:00:00";

            // Снова разрешаем менять время
            numericHours.Enabled = true;
            numericMinutes.Enabled = true;
            numericSeconds.Enabled = true;

            // Возвращаем состояние кнопок
            buttonStart.Enabled = true;
            buttonCancel.Enabled = false;
        }

        /// <summary>
        /// Событие, которое вызывается каждую секунду
        /// </summary>
        private void timer1_Tick(object sender, EventArgs e)
        {
            // Уменьшаем оставшееся время на одну секунду
            remainingTime = remainingTime.Subtract(
                TimeSpan.FromSeconds(1));

            // Защита от отрицательного времени
            if (remainingTime.TotalSeconds < 0)
            {
                remainingTime = TimeSpan.Zero;
            }

            // Обновляем надпись на форме
            UpdateTimeLabel();

            // Если время закончилось — выключаем компьютер
            if (remainingTime.TotalSeconds <= 0)
            {
                timer1.Stop();
                timerIsRunning = false;

                // Запускаем выключение Windows
                ShutdownComputer();
            }
        }

        /// <summary>
        /// Обновляет текст с оставшимся временем
        /// </summary>
        private void UpdateTimeLabel()
        {
            // Формат: часы:минуты:секунды
            labelTime.Text = string.Format(
                "{0:00}:{1:00}:{2:00}",
                (int)remainingTime.TotalHours,
                remainingTime.Minutes,
                remainingTime.Seconds);
        }

        /// <summary>
        /// Выключает компьютер
        /// ИЗМЕНЕНО: убрано всплывающее окно подтверждения
        /// Если выключение невозможно — компьютер отправляется в сон
        /// </summary>
        private void ShutdownComputer()
        {
            try
            {
                // Получаем полный путь к системной программе Windows
                string shutdownPath = Environment.ExpandEnvironmentVariables(
                    @"%WINDIR%\System32\shutdown.exe");

                // /s — выключение компьютера
                // /t 0 — выключить без дополнительной задержки
                // /f — принудительно закрыть приложения (попытка)
                ProcessStartInfo startInfo = new ProcessStartInfo(
                    shutdownPath,
                    "/s /t 0 /f");
                startInfo.CreateNoWindow = true;
                startInfo.UseShellExecute = false;

                Process shutdownProcess = Process.Start(startInfo);

                // Ждём завершения процесса выключения
                shutdownProcess.WaitForExit();

                // Если код выхода не 0, значит выключение не удалось
                // (мешают программы) — отправляем компьютер в сон
                if (shutdownProcess.ExitCode != 0)
                {
                    SleepComputer();
                }
            }
            catch
            {
                // Если произошла ошибка — отправляем компьютер в сон
                SleepComputer();
            }
        }

        /// <summary>
        /// Отправляет компьютер в режим сна
        /// ИЗМЕНЕНО: добавлен новый метод для перехода в сон
        /// </summary>
        private void SleepComputer()
        {
            try
            {
                // Альтернативный способ через вызов API
                Application.SetSuspendState(
                    PowerState.Suspend,
                    false,
                    true);
            }
            catch
            {
                try
                {
                    string shutdownPath = Environment.ExpandEnvironmentVariables(
                        @"%WINDIR%\System32\shutdown.exe");
                    Process.Start(shutdownPath, "/h");
                }
                catch
                {
                }
            }
        }

        /// <summary>
        /// Отменяет запланированное выключение Windows
        /// </summary>
        private void CancelWindowsShutdown()
        {
            try
            {
                // /a — отменить запланированное выключение
                string shutdownPath = Environment.ExpandEnvironmentVariables(
                    @"%WINDIR%\System32\shutdown.exe");

                Process.Start(
                    shutdownPath,
                    "/a");
            }
            catch
            {
                // Если выключение ещё не было запланировано,
                // Windows может вернуть ошибку.
                // В этом случае ничего делать не нужно.
            }
        }

        /// <summary>
        /// Изменение режима «поверх остальных окон»
        /// </summary>
        private void checkBoxTopMost_CheckedChanged(
            object sender,
            EventArgs e)
        {
            // Если флажок установлен — окно поверх остальных
            this.TopMost = checkBoxTopMost.Checked;
        }

        /// <summary>
        /// Обработка закрытия программы
        /// </summary>
        protected override void OnFormClosing(
            FormClosingEventArgs e)
        {
            // Если таймер был запущен, спрашиваем подтверждение
            if (timerIsRunning)
            {
                DialogResult result = MessageBox.Show(
                    "Таймер запущен. Отменить таймер и закрыть программу?",
                    "Подтверждение",
                    MessageBoxButtons.YesNo,
                    MessageBoxIcon.Question);

                // Если пользователь передумал закрывать программу
                if (result == DialogResult.No)
                {
                    e.Cancel = true;
                    return;
                }

                // Останавливаем таймер
                timer1.Stop();

                // Отменяем выключение Windows
                CancelWindowsShutdown();
            }

            // Завершаем стандартную процедуру закрытия формы
            base.OnFormClosing(e);
        }

        private void numericHours_ValueChanged(object sender, EventArgs e)
        {

        }

        private void numericMinutes_ValueChanged(object sender, EventArgs e)
        {

        }
    }
}