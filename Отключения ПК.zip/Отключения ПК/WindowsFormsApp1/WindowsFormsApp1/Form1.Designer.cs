﻿namespace WindowsFormsApp1
{
    partial class Form1
    {
        /// <summary>
        /// Контейнер компонентов формы
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Таймер Windows Forms
        /// </summary>
        private System.Windows.Forms.Timer timer1;

        /// <summary>
        /// Заголовок формы
        /// </summary>
        private System.Windows.Forms.Label labelTitle;

        /// <summary>
        /// Надпись с оставшимся временем
        /// </summary>
        private System.Windows.Forms.Label labelTime;

        /// <summary>
        /// Поле выбора часов
        /// </summary>
        private System.Windows.Forms.NumericUpDown numericHours;

        /// <summary>
        /// Поле выбора минут
        /// </summary>
        private System.Windows.Forms.NumericUpDown numericMinutes;

        /// <summary>
        /// Поле выбора секунд
        /// </summary>
        private System.Windows.Forms.NumericUpDown numericSeconds;

        /// <summary>
        /// Подпись часов
        /// </summary>
        private System.Windows.Forms.Label labelHours;

        /// <summary>
        /// Подпись минут
        /// </summary>
        private System.Windows.Forms.Label labelMinutes;

        /// <summary>
        /// Подпись секунд
        /// </summary>
        private System.Windows.Forms.Label labelSeconds;

        /// <summary>
        /// Кнопка запуска таймера
        /// </summary>
        private System.Windows.Forms.Button buttonStart;

        /// <summary>
        /// Кнопка отмены таймера
        /// </summary>
        private System.Windows.Forms.Button buttonCancel;

        /// <summary>
        /// Флажок режима поверх всех окон
        /// </summary>
        private System.Windows.Forms.CheckBox checkBoxTopMost;

        /// <summary>
        /// Освобождение ресурсов формы
        /// </summary>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }

            base.Dispose(disposing);
        }

        #region Код, созданный конструктором Windows Forms

        /// <summary>
        /// Создание элементов формы
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.labelTitle = new System.Windows.Forms.Label();
            this.labelTime = new System.Windows.Forms.Label();
            this.numericHours = new System.Windows.Forms.NumericUpDown();
            this.numericMinutes = new System.Windows.Forms.NumericUpDown();
            this.numericSeconds = new System.Windows.Forms.NumericUpDown();
            this.labelHours = new System.Windows.Forms.Label();
            this.labelMinutes = new System.Windows.Forms.Label();
            this.labelSeconds = new System.Windows.Forms.Label();
            this.buttonStart = new System.Windows.Forms.Button();
            this.buttonCancel = new System.Windows.Forms.Button();
            this.checkBoxTopMost = new System.Windows.Forms.CheckBox();
            ((System.ComponentModel.ISupportInitialize)(this.numericHours)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericMinutes)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericSeconds)).BeginInit();
            this.SuspendLayout();
            // 
            // timer1
            // 
            this.timer1.Interval = 1000;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // labelTitle
            // 
            this.labelTitle.AutoSize = true;
            this.labelTitle.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold);
            this.labelTitle.Location = new System.Drawing.Point(229, 30);
            this.labelTitle.Name = "labelTitle";
            this.labelTitle.Size = new System.Drawing.Size(243, 24);
            this.labelTitle.TabIndex = 0;
            this.labelTitle.Text = "Таймер выключения ПК";
            // 
            // labelTime
            // 
            this.labelTime.Font = new System.Drawing.Font("Consolas", 28F, System.Drawing.FontStyle.Bold);
            this.labelTime.ForeColor = System.Drawing.Color.DarkBlue;
            this.labelTime.Location = new System.Drawing.Point(203, 71);
            this.labelTime.Name = "labelTime";
            this.labelTime.Size = new System.Drawing.Size(260, 55);
            this.labelTime.TabIndex = 1;
            this.labelTime.Text = "00:00:00";
            this.labelTime.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // numericHours
            // 
            // ИЗМЕНЕНО: Size с 60, 20 на 60, 40
            // ИЗМЕНЕНО: Font увеличен в 2 раза и сделан жирным
            this.numericHours.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.numericHours.Location = new System.Drawing.Point(100, 155);
            this.numericHours.Maximum = new decimal(new int[] {
            24,
            0,
            0,
            0});
            this.numericHours.Name = "numericHours";
            this.numericHours.Size = new System.Drawing.Size(60, 40);
            this.numericHours.TabIndex = 2;
            this.numericHours.Value = new decimal(new int[] {
            2,
            0,
            0,
            0});
            this.numericHours.ValueChanged += new System.EventHandler(this.numericHours_ValueChanged);
            // 
            // numericMinutes
            // 
            // ИЗМЕНЕНО: Size с 60, 20 на 60, 40
            // ИЗМЕНЕНО: Font увеличен в 2 раза и сделан жирным
            this.numericMinutes.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.numericMinutes.Location = new System.Drawing.Point(286, 155);
            this.numericMinutes.Maximum = new decimal(new int[] {
            59,
            0,
            0,
            0});
            this.numericMinutes.Name = "numericMinutes";
            this.numericMinutes.Size = new System.Drawing.Size(60, 40);
            this.numericMinutes.TabIndex = 3;
            this.numericMinutes.ValueChanged += new System.EventHandler(this.numericMinutes_ValueChanged);
            // 
            // numericSeconds
            // 
            // ИЗМЕНЕНО: Size с 60, 20 на 60, 40
            // ИЗМЕНЕНО: Font увеличен в 2 раза и сделан жирным
            this.numericSeconds.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.numericSeconds.Location = new System.Drawing.Point(465, 155);
            this.numericSeconds.Maximum = new decimal(new int[] {
            59,
            0,
            0,
            0});
            this.numericSeconds.Name = "numericSeconds";
            this.numericSeconds.Size = new System.Drawing.Size(60, 40);
            this.numericSeconds.TabIndex = 4;
            // 
            // labelHours
            // 
            this.labelHours.AutoSize = true;
            this.labelHours.Location = new System.Drawing.Point(125, 180);
            this.labelHours.Name = "labelHours";
            this.labelHours.Size = new System.Drawing.Size(35, 13);
            this.labelHours.TabIndex = 5;
            this.labelHours.Text = "Часы";
            // 
            // labelMinutes
            // 
            this.labelMinutes.AutoSize = true;
            this.labelMinutes.Location = new System.Drawing.Point(300, 180);
            this.labelMinutes.Name = "labelMinutes";
            this.labelMinutes.Size = new System.Drawing.Size(46, 13);
            this.labelMinutes.TabIndex = 6;
            this.labelMinutes.Text = "Минуты";
            // 
            // labelSeconds
            // 
            this.labelSeconds.AutoSize = true;
            this.labelSeconds.Location = new System.Drawing.Point(474, 180);
            this.labelSeconds.Name = "labelSeconds";
            this.labelSeconds.Size = new System.Drawing.Size(51, 13);
            this.labelSeconds.TabIndex = 7;
            this.labelSeconds.Text = "Секунды";
            // 
            // buttonStart
            // 
            this.buttonStart.Location = new System.Drawing.Point(148, 301);
            this.buttonStart.Name = "buttonStart";
            this.buttonStart.Size = new System.Drawing.Size(125, 35);
            this.buttonStart.TabIndex = 8;
            this.buttonStart.Text = "Запустить";
            this.buttonStart.UseVisualStyleBackColor = true;
            this.buttonStart.Click += new System.EventHandler(this.buttonStart_Click);
            // 
            // buttonCancel
            // 
            this.buttonCancel.Location = new System.Drawing.Point(400, 301);
            this.buttonCancel.Name = "buttonCancel";
            this.buttonCancel.Size = new System.Drawing.Size(125, 35);
            this.buttonCancel.TabIndex = 9;
            this.buttonCancel.Text = "Отменить";
            this.buttonCancel.UseVisualStyleBackColor = true;
            this.buttonCancel.Click += new System.EventHandler(this.buttonCancel_Click);
            // 
            // checkBoxTopMost
            // 
            this.checkBoxTopMost.AutoSize = true;
            this.checkBoxTopMost.Checked = true;
            this.checkBoxTopMost.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBoxTopMost.Location = new System.Drawing.Point(260, 379);
            this.checkBoxTopMost.Name = "checkBoxTopMost";
            this.checkBoxTopMost.Size = new System.Drawing.Size(147, 17);
            this.checkBoxTopMost.TabIndex = 10;
            this.checkBoxTopMost.Text = "Окно поверх остальных";
            this.checkBoxTopMost.CheckedChanged += new System.EventHandler(this.checkBoxTopMost_CheckedChanged);
            // 
            // Form1
            // 
            // ИЗМЕНЕНО: Text с "Таймер выключения компьютера" на "Отключение ПК"
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.CornflowerBlue;
            this.ClientSize = new System.Drawing.Size(675, 445);
            this.Controls.Add(this.labelTitle);
            this.Controls.Add(this.labelTime);
            this.Controls.Add(this.numericHours);
            this.Controls.Add(this.numericMinutes);
            this.Controls.Add(this.numericSeconds);
            this.Controls.Add(this.labelHours);
            this.Controls.Add(this.labelMinutes);
            this.Controls.Add(this.labelSeconds);
            this.Controls.Add(this.buttonStart);
            this.Controls.Add(this.buttonCancel);
            this.Controls.Add(this.checkBoxTopMost);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Отключение ПК";
            this.TopMost = true;
            ((System.ComponentModel.ISupportInitialize)(this.numericHours)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericMinutes)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericSeconds)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
    }
}